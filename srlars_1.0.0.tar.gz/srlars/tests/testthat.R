library(testthat)
library(srlars)

test_check("srlars")
